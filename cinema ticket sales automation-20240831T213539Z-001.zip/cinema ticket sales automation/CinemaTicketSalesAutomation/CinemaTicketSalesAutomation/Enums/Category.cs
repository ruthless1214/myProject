﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketSalesAutomation.Enums
{
    public enum Category
    {
        bilim_kurgu,gerilim,macera,fantastik,komedi
    }
}
