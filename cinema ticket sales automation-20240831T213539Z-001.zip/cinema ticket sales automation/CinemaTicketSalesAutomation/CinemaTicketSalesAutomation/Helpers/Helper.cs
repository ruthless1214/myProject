﻿using CinemaTicketSalesAutomation.Enums;
using CinemaTicketSalesAutomation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketSalesAutomation.Helpers
{
    public class Helper
    {
        public static List<Movie> CreateMovies()
        {
            string basePath = "C:/Users/alper/OneDrive/Masaüstü/c#/cinema ticket sales automation/CinemaTicketSalesAutomation/CinemaTicketSalesAutomation/Pictures"; // dosya değişiminde kolaylık 
            return new List<Movie>()
            {
                new Movie()
                {
                    movieName = "Yıldızlararası",
                    category = Category.bilim_kurgu,
                    minute = "2 saat",
                    price = 40,
                    picturePath = basePath + "Yıldızlararası.jpg"
                },
                new Movie()
                {
                    movieName = "Diktatör",
                    category = Category.komedi,
                    minute = "2 saat",
                    price = 31,
                    picturePath = basePath + "diktator.jpg"
                },
                 new Movie()
                {
                    movieName = "Avatar",
                    category = Category.fantastik,
                    minute = "2 saat 16 dakika",
                    price = 69,
                    picturePath = basePath + "Avatar.jpg"
                },
                  new Movie()
                {
                    movieName = "Jumanji",
                    category = Category.fantastik,
                    minute = "1 saat 45 dakika",
                    price = 35,
                    picturePath = basePath + "Jumanji.jpg"
                },
                   new Movie()
                {
                    movieName = "Warcraft",
                    category = Category.macera,
                    minute = "1 saat 49 dakika",
                    price = 46,
                    picturePath = basePath + "Warcraft.jpg"
                },
                    new Movie()
                {
                    movieName = "Zindan Adası",
                    category = Category.gerilim,
                    minute = "2 saat 3 dakika",
                    price = 55,
                    picturePath = basePath + "zindan adası.jpg"
                },
            };
        }
    }
}
