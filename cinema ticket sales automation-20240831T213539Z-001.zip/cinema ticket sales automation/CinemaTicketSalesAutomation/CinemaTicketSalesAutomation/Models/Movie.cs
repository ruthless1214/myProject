﻿using CinemaTicketSalesAutomation.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketSalesAutomation.Models
{
    public class Movie: BaseClass                                                                     
    {

        public Movie()
        {
            SetDefaultSessions();
        }

        public string picturePath { get; set; }
        public string minute { get; set; }
        public decimal price { get; set; }
        public Category category { get; set; }             //category 'enum'
        public List<Session> sessions { get; set; }

        private void SetDefaultSessions()
        {
            sessions = new List<Session>();
            DateTime currentDate = DateTime.Now;  // crntdate sadece tarih. Now hem saat hem tarih.Bu yüzden timespan
            TimeSpan ts = new TimeSpan(10,30,0);  // crntdateden tarihi ts den saati alıp birleştirecek 

            for (int i = 0; i < 3; i++)    // 3 kere dönecek çünkü bugün,yarın,ondan sonraki gün olacak
            {
                currentDate = currentDate.Date + ts;         // gün ve saat
                
                for (int j = 0; j < 3; j++)    // 3 farklı seans olduğu için j = 3
                {
                    Session session = new Session();
                    session.date = currentDate.ToShortDateString();  //hem tarihi dönecek hem de string olarak dönecek
                    session.time = currentDate.ToShortTimeString();
                    sessions.Add(session);
                    currentDate = currentDate.AddHours(3); // seanslar 3 saat arayla bu yüzden 3 saat ekleyecek
                }
                currentDate = currentDate.AddDays(1);   // ilk forda 1 gün sonrasına götürecek

            }
        }
    }
}
