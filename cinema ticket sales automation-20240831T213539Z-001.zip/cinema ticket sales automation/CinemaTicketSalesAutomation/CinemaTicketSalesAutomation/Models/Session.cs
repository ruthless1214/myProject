﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketSalesAutomation.Models
{
    public class Session
    {
        public Session()   // ctor kurucu metod (sınıftan instance alındığı zaman ilk çalışacak metod) 
                           // bu yüzden başlangıç değerlerini burada atıyorum
        {
            SetDefaultChairs();
        }
        public string date { get; set; }
        public string time { get; set; }
        public List<Chair> chairs { get; set; }

        private void SetDefaultChairs()   // ctor içi dolmasın diye bu metodu ctor içinde çağıracağım
        {
            chairs = new List<Chair>();    // add kullanarak chair eklerken adres veya obje bulmasını sağlayacak
            string[] rows = { "A", "B", "C", "D" };
            string[] numbers = { "1","2","3","4","5","6"};

            foreach (string row in rows) // içine number atabilmek için rowla dönmeli. dışta olan row a1 a2 a3 gibi
            { 
                foreach (string number in numbers)
                {
                    Chair chair = new Chair(row, number);  // ilk chair oluştu --> A1
                    chairs.Add(chair);                     // bütün salondaki koltukları atamış olduk
                }
            }   

        }
    }
}
