﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketSalesAutomation.Models
{
    public class Sales:BaseClass   /* bu sınıfa movieName de dahil ancak BaseClasstan aldığım için buraya prop
                                    eklememe gerek yok */
    {
        public Sales()
        {
            creationDate = DateTime.Now.ToString();
        }
        public string creationDate { get; set; }
        public decimal totalPrice { get; set; }
        public int count { get; set; }
        public string sessionTime { get; set; }

        public override string ToString() /* polimorfizm. birden fazla yerde farklı şekilde kullanılmak üzere virtual 
                                           * olarak işaretlenen kodun içeriğini değiştirebilmek adına override ettik */
        {
            return $"{movieName} filminin {sessionTime} seansına {count} adet bilet kesilmiştir.\nToplam tutar = {totalPrice} TL\nİşlem tarihi = {creationDate} ";
        }
    }
}
