﻿using CinemaTicketSalesAutomation.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CinemaTicketSalesAutomation
{
    public partial class Form2 : Form
    {
        public Form2(List<Movie> _movies,Form1 _form1)
        {
            InitializeComponent();
            movies = _movies;
            form1 = _form1;
        }
        List<Movie> movies;
        Form1 form1;
        Movie selectedMovie;
        Session selectedSession;
        


        public void ListDetail(int movieIndex, string _time, string _date)// gizlenen form1deki ögeleri form2 ye al
        {
            selectedMovie = movies[movieIndex];
            selectedSession = selectedMovie.sessions.Find(s => s.date == _date && s.time == _time);
                          // movies içindeki sessionlara gittim ve List <> özelliği olan find kullandım.
                          // sessiondate ve sessiontime eşleşirse Find değer döndürecek ve selectedSession bulunacak
            lblTime.Text = $"{_date} - {_time}"; // gönderdiğim zaman ve tarihi ekrana yazdım 
            lblDakika.Text = selectedMovie.minute;
            lblUcret.Text = selectedMovie.price.ToString();  //price decimal
            pbSelectedPicture.Image = Image.FromFile(selectedMovie.picturePath);  // ayarını form2 de yaptım
            lblKategori.Text = selectedMovie.category.ToString();
            checkChairsStatus();
        }

        private void checkChairsStatus()
        {
            foreach (Control item in grbChairs.Controls)
            {
                if (item is Button) //sadece butonları kontrol etmek istediğim için
                               // button, buttonBase den miras aldı. buttonBase 'Control'den miras aldı ve tag Control içinde bulunur bu yüzden tekrar butona çevirmeye gerek yok ama duruma göre item butona çevrilebilirdi
                {
                    string row = item.Tag.ToString();
                    string number = item.Text;
                    item.Enabled = true;   // ilk başta aktif edip duruma göre pasifleştireceğiz 
                    foreach (Chair chair in selectedSession.chairs)
                    {
                        if (chair.row == row && chair.number == number)
                        {
                            if (chair.status) //seçilen butonlar chair eşleşiyorsa status kontrol edilecek renk değişecek
                            {
                                item.BackColor = Color.DarkOrange;
                                item.Enabled = false;
                            }
                            else
                            {
                                item.BackColor = Color.LightGreen;
                            }
                            break;
                        }
                    }
                }
            }
        }
        List<Chair> chairs = new List<Chair>(); // seçilen butonları seçilmeyenlerden ayrı tutacak 
        private void button24_Click(object sender, EventArgs e) //tüm chair butonu clik eventi bu metodda
        {
            Button button = sender as Button;
            string row = button.Tag.ToString();
            string number = button.Text;
            Chair chair = selectedSession.chairs.Find(c => c.row == row && c.number == number);
            if (button.BackColor.Name != "Blue") 
            {
                chairs.Add(chair); 
                button.BackColor = Color.Yellow;  //Satın alınmak üzere olan koltuğu sarı olarak belirtecek
            }
            else
            {
                chairs.Remove(chair);
                button.BackColor = Color.LightGreen; // seçilen koltuklar tekrar seçilemeyeceği için koltukları meşgul göstermek adına rengi açık yeşil gösterecek

            }
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (chairs.Count == 0)
            {
                MessageBox.Show("En az 1 koltuk seç.");
                return;
            }
            Sales sales = new Sales();
            sales.movieName = selectedMovie.movieName;
            sales.count = chairs.Count;
            sales.sessionTime = $"{selectedSession.date} - {selectedSession.time}";
            sales.totalPrice = CalculatePrice();

            foreach (Chair chair in chairs) //dolu koltukların belirtilmesi
            {
                chair.status = true; //selectedSession.Chair içindeki ilgili chairın statüsünü true yaptı
            } 

            MessageBox.Show(sales.ToString()); /* mboxta bilgilendirme mesajı görmek için ToStringi override etmen                                        gerek aksi taktirde dosya yolu gözükecek. yapmak için sales sınıfına                                    git. override işleminden sonra sales sınıfında override ettiğin                                         değeri göreceksin */
            ChangePage();

        }
        private void ChangePage ()  // form2 de işlem bittikten sonra form1e dön ve eski işlemleri temizle
        {
            rbSmall.Checked = rbMedium.Checked = rbLarge.Checked =false;
            chairs.Clear();
            this.Hide();
            form1.Show();
        }
        private decimal CalculatePrice()
        {
            decimal price = selectedMovie.price * chairs.Count;
            if (rbSmall.Checked)
            {
                price += 3;
            }
            else if (rbMedium.Checked)
            {
                price += 5;
            }
            else if (rbLarge.Checked)
            {
                price += 9;
            }
            return price;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ChangePage();  // form1 e dön ve işlemleri temizle
        }

       
    }
}
