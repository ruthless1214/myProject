﻿namespace CinemaTicketSalesAutomation
{
    public class Movies
    {
    }
}