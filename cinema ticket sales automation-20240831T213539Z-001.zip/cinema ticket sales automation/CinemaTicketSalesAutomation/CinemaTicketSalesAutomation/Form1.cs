﻿using CinemaTicketSalesAutomation.Helpers;
using CinemaTicketSalesAutomation.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CinemaTicketSalesAutomation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Movie> movies;
        DateTime currentDate = DateTime.Now; // değişmeyecek her zaman ulaşılabilecek
        DateTime useDate;                    // değişkenlik gösterecek DT. (seanslar gün olarak da değiştiği için,) 
        Form2 form2;
        private void Form1_Load(object sender, EventArgs e)
        {
            useDate = currentDate;             // başlangıç değerini bugün olarak atamak amaçlı
            lblDate.Text = useDate.ToShortDateString(); // hangi tarihteysek onun seanslarını gösterecek
            movies = Helper.CreateMovies();
            ListControls();
            form2 = new Form2(movies,this);   //hata almamak için ctora form2 de veri girilmeli (movies ve form1)
        }

        private void ListControls()
        {
            Size pictureSize = new Size(300, 180);
            Size buttonSize = new Size(90, 40);
            int x = 50;                          // dikey ve yatay uzaklıkların başlangıç değerleri
            int y = 100;               
            int xIncrement = 400;                // dikey ve yatay uzaklıkların artış değerleri
            int yIncrement = 300;

            for (int i = 0; i < movies.Count; i++)    //ilk picture
            {
                PictureBox picture = new PictureBox();   // pic box oluşturduk
                picture.Location = new Point(x, y);      // x ve y değerlerini yukarıda tanımladım buna göre oluşacak
                picture.Size = pictureSize;
               // picture.Image = Image.FromFile(movies[i].picturePath);  // dosya yolunu image' dönüştürecek
                picture.SizeMode = PictureBoxSizeMode.StretchImage;  // pic box smode enum 
                this.Controls.Add(picture);
                int buttonX = x;
                int buttonY = picture.Bottom + 10;

                for (int index = 0; index < 3; index++)    // 3 farklı buton için 3 kez dönmeli 
                {
                    Button button = new Button();
                    button.Text = movies[i].sessions[index].time;
                    button.Location = new Point(buttonX, buttonY);   // değerleri yukarıda atadık 
                    button.Size = buttonSize;
                    button.Tag = i;                    // moviesin indexini çektik
                    button.Click += new EventHandler(button_Click);
                    this.Controls.Add(button);         // ilk butonu kontrollere ekledim 
                    buttonX += 100;      // sonraki butonu eklemek için 100 arttırmalıyız 

                }
                
                if ( 1200 > x + xIncrement + picture.Width)     //ilk satır dolunca aşağıya inecek
                {
                    x += xIncrement;
                }
               
                else
                {
                    x = 50;               // yeni satıra geçtiğim için, yatay değerin başlangıç değerine dönmesi gerek
                    y += yIncrement;      // sütunda aşağıya ineceğim için dikey değer artacak
                }
            }
        }

        private void button_Click(object sender, EventArgs e)  //bütün butonların click eventi burada çalışacak
        {
            Button button = sender as Button;   // sender objesi butona çevrildi  cliklemek için butonu seçmiştik
            int movieIndex = Convert.ToInt32(button.Tag); //tag moviesin indexini tutuyordu (index int olarak tutulur)
                                                          //tag obje olduğu için convert edildi
            string sessionTime = button.Text;   //sessionın timeı button text de olduğu için bu şekilde alındı
            string sessionDate = lblDate.Text;  //günü form1 loadda lblDate içinde atadık 
            if (DateTime.Parse($"{sessionDate} {sessionTime}") < DateTime.Now)
            {
                MessageBox.Show("Geçmiş bir tarihten seans seçemezsiniz. Başka bir seans deneyin.");
                return;                               //metod içinden çıkmayı sağlayacak 
            }
            this.Hide();          // form1 gizlendi
            form2.Show();         // form2 gösterildi
            form2.ListDetail(movieIndex,sessionTime,sessionDate); // public olduğu için kolayca çağırdım
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            useDate = useDate.AddDays(1); 
            lblDate.Text = useDate.ToShortDateString();
            btnPrevious.Enabled = true;     //1 gün ileri gittiğim için artık geçtiğim güne gidebilirim
            if (currentDate.AddDays(2) == useDate)
            {
                btnNext.Enabled = false;  // max 3 gün seans seçebilirim sonraki günler yok 
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            useDate = useDate.AddDays(-1);
            lblDate.Text = useDate.ToShortDateString();
            btnNext.Enabled = true;
            if (currentDate == useDate)
            {
                btnPrevious.Enabled = false;
            }
        }
    }
}
